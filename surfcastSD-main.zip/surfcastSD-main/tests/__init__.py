"""Tests for SurfCast SD."""
